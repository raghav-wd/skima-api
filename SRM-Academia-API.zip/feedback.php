<?php
include 'simple_html_dom.php';

$str = '';